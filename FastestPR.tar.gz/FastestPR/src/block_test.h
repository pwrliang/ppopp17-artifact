#include <iostream>
#include <graph/graph.h>
#include <graph/block.h>
#include <kernel/blockcentric.cuh>

int run() {
#ifdef TEST
	char blocks_num = 4;
	char thread_num = 2;
	agraph::graph g(17);
	g.load_graph("/home/liang/test_dataset");
#else
	char blocks_num = 20;
	int thread_num = 128;
	agraph::graph g(875713);
	g.load_graph("/home/liang/Datasets/google_adj_replaced.txt");
#endif
//	agraph::graph g(875713);
//	g.load_graph("/home/liang/Datasets/google_adj_replaced.txt");
	char **pp_blk_id = new char*[g.get_vertex_num()];
	int **pp_adj_pos = new int*[g.get_vertex_num()]; //[v_idx][adj_idx] = {dst_vid or buffer id}
	int **pp_src_dst_buf_sz = new int*[blocks_num];
	int ***ppp_src_dst_pos = new int**[blocks_num];
	int *p_lbound = new int[blocks_num];
	int *p_ubound = new int[blocks_num];

	for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
		pp_blk_id[v_idx] = new char[g.get_adj(v_idx)->size()];
		pp_adj_pos[v_idx] = new int[g.get_adj(v_idx)->size()];
	}

	for (int blk_idx = 0; blk_idx < blocks_num; blk_idx++) {
		pp_src_dst_buf_sz[blk_idx] = new int[blocks_num];
		ppp_src_dst_pos[blk_idx] = new int*[blocks_num];
	}

	printf("building index\n");

	agraph::build_index(blocks_num, g, p_lbound, p_ubound, pp_blk_id, pp_adj_pos, pp_src_dst_buf_sz, ppp_src_dst_pos);

	printf("send table:\n");

//	for (int blk_id = 0; blk_id < blocks_num; blk_id++) {
//		printf("%d - %d\n", p_lbound[blk_id], p_ubound[blk_id]);
//	}
//	agraph::block_list b_list;
//	for (int b_id = 0; b_id < blocks_num; b_id++) {
//		agraph::block blk(b_id);
//		b_list.push_back(blk);
//	}
//
//	agraph::block::split_to_block_avg(g, blocks_num, b_list);

	char **d_pp_blk_id;
	int **d_pp_adj_pos;

	CHECK(cudaMallocManaged(&d_pp_blk_id, sizeof(char*) * g.get_vertex_num()));
	CHECK(cudaMallocManaged(&d_pp_adj_pos, sizeof(int*) * g.get_vertex_num()));

	for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
		CHECK(cudaMalloc(&d_pp_blk_id[v_idx], sizeof(char) * g.get_adj(v_idx)->size()));
		CHECK(cudaMemcpy(d_pp_blk_id[v_idx], pp_blk_id[v_idx], sizeof(char) * g.get_adj(v_idx)->size(), cudaMemcpyHostToDevice));

		CHECK(cudaMalloc(&d_pp_adj_pos[v_idx], sizeof(int) * g.get_adj(v_idx)->size()));
		CHECK(cudaMemcpy(d_pp_adj_pos[v_idx], pp_adj_pos[v_idx], sizeof(int) * g.get_adj(v_idx)->size(), cudaMemcpyHostToDevice));
	}

	int **d_pp_src_dst_buf_sz;
	int ***d_ppp_src_dst_pos;

	CHECK(cudaMallocManaged(&d_pp_src_dst_buf_sz, sizeof(int*) * blocks_num));
	CHECK(cudaMallocManaged(&d_ppp_src_dst_pos, sizeof(int**) * blocks_num));

	float ***d_ppp_delta_buffer;
	CHECK(cudaMallocManaged(&d_ppp_delta_buffer, sizeof(float**) * blocks_num));

	for (int src_blk_idx = 0; src_blk_idx < blocks_num; src_blk_idx++) {
		CHECK(cudaMalloc(&d_pp_src_dst_buf_sz[src_blk_idx], sizeof(int) * blocks_num));
		CHECK(cudaMemcpy(d_pp_src_dst_buf_sz[src_blk_idx], pp_src_dst_buf_sz[src_blk_idx], sizeof(int) * blocks_num, cudaMemcpyHostToDevice));

		CHECK(cudaMallocManaged(&d_ppp_src_dst_pos[src_blk_idx], sizeof(int*) * blocks_num));

		CHECK(cudaMallocManaged(&d_ppp_delta_buffer[src_blk_idx], sizeof(float*) * blocks_num));

		for (int dst_blk_idx = 0; dst_blk_idx < blocks_num; dst_blk_idx++) {
			if (src_blk_idx == dst_blk_idx)
				continue;

			int blk_sz = pp_src_dst_buf_sz[src_blk_idx][dst_blk_idx];

			CHECK(cudaMalloc(&d_ppp_src_dst_pos[src_blk_idx][dst_blk_idx], sizeof(int) * blk_sz));
			CHECK(
					cudaMemcpy(d_ppp_src_dst_pos[src_blk_idx][dst_blk_idx], ppp_src_dst_pos[src_blk_idx][dst_blk_idx], sizeof(int) * blk_sz,
							cudaMemcpyHostToDevice));

			CHECK(cudaMalloc(&d_ppp_delta_buffer[src_blk_idx][dst_blk_idx], sizeof(float) * blk_sz));
			CHECK(cudaMemset(d_ppp_delta_buffer[src_blk_idx][dst_blk_idx], 0, sizeof(float) * blk_sz));

		}
	}

	int *d_p_lbound, *d_p_ubound;

	CHECK(cudaMalloc(&d_p_lbound, sizeof(int) * blocks_num));
	CHECK(cudaMemcpy(d_p_lbound, p_lbound, sizeof(int) * blocks_num, cudaMemcpyHostToDevice));

	CHECK(cudaMalloc(&d_p_ubound, sizeof(int) * blocks_num));
	CHECK(cudaMemcpy(d_p_ubound, p_ubound, sizeof(int) * blocks_num, cudaMemcpyHostToDevice));

	int *d_p_degree;
	int *p_degree = new int[g.get_vertex_num()];

	CHECK(cudaMalloc(&d_p_degree, sizeof(int) * g.get_vertex_num()));

	for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++)
		p_degree[v_idx] = g.get_adj(v_idx)->size();

	CHECK(cudaMemcpy(d_p_degree, p_degree, sizeof(int) * g.get_vertex_num(), cudaMemcpyHostToDevice));

	float *p_value = new float[g.get_vertex_num()];
	float *p_delta = new float[g.get_vertex_num()];
	float *p_last_round = new float[g.get_vertex_num()];

	for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
		p_value[v_idx] = 0.0f;
		p_delta[v_idx] = 0.2f / g.get_vertex_num();
		p_last_round[v_idx] = 0.0f;
	}

	float *d_p_value, *d_p_delta, *d_p_last_round;

	CHECK(cudaMalloc(&d_p_value, sizeof(float) * g.get_vertex_num()));
	CHECK(cudaMemcpy(d_p_value, p_value, sizeof(float) * g.get_vertex_num(), cudaMemcpyHostToDevice));

	CHECK(cudaMalloc(&d_p_delta, sizeof(float) * g.get_vertex_num()));
	CHECK(cudaMemcpy(d_p_delta, p_delta, sizeof(float) * g.get_vertex_num(), cudaMemcpyHostToDevice));

	CHECK(cudaMalloc(&d_p_last_round, sizeof(float) * g.get_vertex_num()));
	CHECK(cudaMemcpy(d_p_last_round, p_last_round, sizeof(float) * g.get_vertex_num(), cudaMemcpyHostToDevice));

	float *d_p_buffer;
	int cacheSize = thread_num / 32;

	assert(cacheSize > 0);
	CHECK(cudaMalloc(&d_p_buffer, sizeof(float) * blocks_num));
	CHECK(cudaMemset(d_p_buffer, 0, sizeof(float) * blocks_num));

	float *d_p_local_buffer;

	CHECK(cudaMalloc(&d_p_local_buffer, sizeof(float) * blocks_num * thread_num));
	CHECK(cudaMemset(d_p_local_buffer, 0, sizeof(float) * blocks_num * thread_num));

	float *d_p_last_sum;

	CHECK(cudaMalloc(&d_p_last_sum, sizeof(float) * blocks_num ));
	CHECK(cudaMemset(d_p_last_sum, 0, sizeof(float) * blocks_num));


	bool *d_p_finish_flag;

	CHECK(cudaMalloc(&d_p_finish_flag, sizeof(bool)*blocks_num));

	printf("copy complete\n");
	printf("kernel started\n");

	cudaEvent_t start, stop;
	float running_time;

	CHECK(cudaEventCreate(&start));
	CHECK(cudaEventCreate(&stop));
	CHECK(cudaEventRecord(start));
	agraph::pagerank_block_centric<<<blocks_num, thread_num, cacheSize>>>(d_p_finish_flag, d_p_local_buffer, d_p_last_sum, g.get_vertex_num(), d_p_lbound, d_p_ubound, d_p_degree, d_p_buffer, d_p_value,
			d_p_delta, d_p_last_round, d_pp_blk_id, d_pp_adj_pos, d_ppp_src_dst_pos, d_ppp_delta_buffer, d_pp_src_dst_buf_sz);
	cudaDeviceSynchronize();
	CHECK(cudaEventRecord(stop));
	CHECK(cudaEventSynchronize(stop));
	CHECK(cudaEventElapsedTime(&running_time, start, stop));

	printf("elapsed %f\n", running_time);
//	CHECK(cudaMemcpy(p_value, d_p_value, sizeof(float) * g.get_vertex_num(), cudaMemcpyDeviceToHost));
//	float sum = 0.0f;
//	for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
//		printf("%d %f\n", v_idx, p_value[v_idx]);
//		sum += p_value[v_idx];
//	}
//	printf("done sum:%f\n", sum);
//	for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
//		int degree = g.get_adj(v_idx)->size();
//		int src_blk_idx = agraph::block::get_block_id(b_list, v_idx);
//		agraph::adj_list *p_adj_list = g.get_adj(v_idx);
//
//		for (int adj_idx = 0; adj_idx < degree; adj_idx++) {
//			int dst_blk_idx = pp_blk_id[v_idx][adj_idx];
//			int adj_or_buff_idx = pp_adj_pos[v_idx][adj_idx]; //p_adj_list[adj_idx];
//
//			if (src_blk_idx == dst_blk_idx) {
//				printf("*%d ", adj_or_buff_idx);
//				//printf("%d ", dst_blk_idx);
//			} else {
//				printf("%d-%d [%d] ", dst_blk_idx, adj_or_buff_idx, ppp_src_dst_offset[src_blk_idx][dst_blk_idx][adj_or_buff_idx]);
//			}
//		}
//		printf("\n");
//	}

//	int elems_num = 875713;
//	agraph::graph g(elems_num);
//	g.load_graph("/home/liang/Datasets/google_adj_replaced.txt");
//	char **hd_pp_adj_bid;
//	int **hd_pp_adj_offset;
//	CHECK(cudaMallocManaged(&hd_pp_adj_bid, sizeof(char*) * elems_num));
//	CHECK(cudaMallocManaged(&hd_pp_adj_offset, sizeof(int*) * elems_num));
//	agraph::build_index_on_gpu(20, g, hd_pp_adj_bid, hd_pp_adj_offset);
//	std::cout<<"index built"<<std::endl;
}
