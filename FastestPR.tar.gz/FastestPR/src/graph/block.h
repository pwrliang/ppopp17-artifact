/*
 * block.h
 *
 *  Created on: Jan 18, 2018
 *      Author: liang
 */

#ifndef BLOCK_H_
#define BLOCK_H_
#include <vector>
#include <set>
#include <algorithm>
namespace agraph {
class block;
typedef std::vector<block> block_list;
class block {
private:
	int b_id;
	int lbound;
	int ubound;
	int total_degree;
public:
	block() {
		b_id = -1;
	}

	block(int _b_id) :
			b_id(_b_id) {

	}

	int get_block_id() {
		return b_id;
	}

	int get_lbound() {
		return lbound;
	}

	int get_ubound() {
		return ubound;
	}

	static char get_block_id(block_list &b_list, int v_id) {
		for (char b_id = 0; b_id < b_list.size(); b_id++) {
			if (v_id >= b_list[b_id].get_lbound() && v_id < b_list[b_id].get_ubound())
				return b_id;
		}

		return -1;
	}
	/**
	 * split graph to blocks by out-degree
	 */
	static void split_to_block(graph &g, int blocks_num, block_list &b_list) {
		int total_degree = 0;

		for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
			total_degree += g.get_adj(v_idx)->size();
		}

		int avg_degree = total_degree / blocks_num;
		assert(avg_degree > 0);

		int start_idx = 0;
		int end_idx = 0;
		int degree_in_block = 0;
		int bid = 0;
		for (int v_idx = 0; v_idx < g.get_vertex_num(); v_idx++) {
			degree_in_block += g.get_adj(v_idx)->size();

			if (degree_in_block >= avg_degree) {
				end_idx = v_idx + 1;    // include this vertex

				end_idx = std::min(end_idx, g.get_vertex_num());
				b_list[bid].b_id = bid;
				b_list[bid].lbound = start_idx;
				b_list[bid].ubound = end_idx;
				bid++;
				start_idx = end_idx;
				degree_in_block = 0;
			}
		}
		b_list[bid].lbound = start_idx;
		b_list[bid].ubound = g.get_vertex_num();
	}

	static void split_to_block_avg(graph &g, int blocks_num, block_list &b_list) {
		int width = g.get_vertex_num() / blocks_num;
		assert(width > 0);

		for (int bid = 0; bid < blocks_num; bid++) {
			int start_idx = bid * width;
			int end_idx = (bid + 1) * width;
			if (bid == blocks_num - 1)
				end_idx = g.get_vertex_num();

			b_list[bid].lbound = start_idx;
			b_list[bid].ubound = end_idx;
		}
	}
};

/**
 * build index for adjacent table based on table partitions
 * @param elems_num the number of elements
 * @param p_lbounds point to an array which contains the lower bound for each block
 * @param p_ubounds point to an array which contains the upper bound for each block
 * @param pp_adj point to 1-dim array which contains the adjacent vertex
 * @return
 */
void build_index_on_gpu(int blocks_num, agraph::graph &g, char **hd_pp_adj_bid, int **hd_pp_adj_offset) {
	agraph::block_list b_list;
	for (int b_id = 0; b_id < blocks_num; b_id++) {
		block blk(b_id);
		b_list.push_back(blk);
	}
	agraph::block::split_to_block(g, blocks_num, b_list);

	for (int b_idx = 0; b_idx < blocks_num; b_idx++) {
		printf("bid %d %d - %d\n", b_list[b_idx].get_block_id(), b_list[b_idx].get_lbound(), b_list[b_idx].get_ubound());
	}

	//for every block
	for (int blk_idx = 0; blk_idx < blocks_num; blk_idx++) {
		agraph::block block = b_list[blk_idx];
		//for every vertex in the block
		for (int v_idx = block.get_lbound(); v_idx < block.get_ubound(); v_idx++) {
			agraph::adj_list *p_adj_list = g.get_adj(v_idx);
			char *h_p_adj_blk_idx = new char[p_adj_list->size()];
			int *h_p_adj_offset = new int[p_adj_list->size()];
			//for every adjacent vertex of the vertex
			int adj_ind = 0;
			for (agraph::adj_list::iterator iter = p_adj_list->begin(); iter != p_adj_list->end(); iter++) {
				int adj = *iter;
				char adj_blk_id = agraph::block::get_block_id(b_list, adj);
				int adj_offset = adj - b_list[adj_blk_id].get_lbound();

				h_p_adj_blk_idx[adj_ind] = adj_blk_id;
				h_p_adj_offset[adj_ind] = adj_offset;
				adj_ind++;
			}
			assert(adj_ind == p_adj_list->size());
			CHECK(cudaMalloc(&hd_pp_adj_bid[v_idx], sizeof(char) * p_adj_list->size()));
			CHECK(cudaMalloc(&hd_pp_adj_offset[v_idx], sizeof(int) * p_adj_list->size()));
			CHECK(cudaMemcpy(hd_pp_adj_bid[v_idx], h_p_adj_blk_idx, sizeof(char) * p_adj_list->size(), cudaMemcpyHostToDevice));
			CHECK(cudaMemcpy(hd_pp_adj_offset[v_idx], h_p_adj_offset, sizeof(int) * p_adj_list->size(), cudaMemcpyHostToDevice));
			delete[] h_p_adj_blk_idx;
			delete[] h_p_adj_offset;
		}
		printf("processed %d\n", blk_idx);
	}
}

int Binary_search(const std::vector<int>& a, int value) {
	int l = 0;
	int r = a.size() - 1;
	while (l <= r) {
		int m = (l + r + 1) / 2;
		if (a[m] == value)
			return m;
		else if (a[m] > value)
			r = m - 1;
		else
			l = m + 1;
	}
	return -1;
}
/**
 * @param pp_blk_idx [vertex index][adjacent vertex index] -> the block id of adjacent vertex
 * @param pp_adj_pos [vertex index][adjacent vertex index] -> {absolute vertex index or index of block}
 * @param pp_src_dst_buf_sz [source vertex's block id][destination vertex's block id] -> block size
 * @param ppp_src_dst_pos [source vertex's block id][destination vertex's block id][index of block] -> adjacent vertex's absolute index
 */
void build_index(int blocks_num, agraph::graph &g,int *p_lbound, int *p_ubound, char **pp_blk_idx, int **pp_adj_pos, int **pp_src_dst_buf_sz, int ***ppp_src_dst_pos) {
	agraph::block_list b_list;
	for (int b_id = 0; b_id < blocks_num; b_id++) {
		block blk(b_id);
		b_list.push_back(blk);
	}

	agraph::block::split_to_block_avg(g, blocks_num, b_list);

	for(int blk_idx=0;blk_idx<blocks_num;blk_idx++){
		p_lbound[blk_idx] = b_list[blk_idx].get_lbound();
		p_ubound[blk_idx] = b_list[blk_idx].get_ubound();
	}

	//for every block
	for (int src_blk_idx = 0; src_blk_idx < blocks_num; src_blk_idx++) {
		agraph::block block = b_list[src_blk_idx];
		std::set<int> *distinct_adj = new std::set<int>[blocks_num];
		// 1. collect all kind of adjacent vertex

		// for every vertex in the block
		for (int v_idx = block.get_lbound(); v_idx < block.get_ubound(); v_idx++) {
			agraph::adj_list *p_adj_list = g.get_adj(v_idx);

			for (agraph::adj_list::iterator iter = p_adj_list->begin(); iter != p_adj_list->end(); iter++) {
				int adj = *iter;
				int adj_idx = iter - p_adj_list->begin();
				char adj_blk_id = agraph::block::get_block_id(b_list, adj);

				pp_blk_idx[v_idx][adj_idx] = adj_blk_id;
				//in block
				if (adj >= block.get_lbound() && adj < block.get_ubound()) {
					pp_adj_pos[v_idx][adj_idx] = adj;
				} else {
					//calculate adj belong to which block
					pp_adj_pos[v_idx][adj_idx] = 0;
					distinct_adj[adj_blk_id].insert(adj);
				}
			}
		}
		// 2.put distinct adjacent vertex which not in src block to vector and sort
		// sort every buffer's index
		std::vector<int> *sorted_distinct_adj = new std::vector<int>[blocks_num];

		for (int dst_blk_idx = 0; dst_blk_idx < blocks_num; dst_blk_idx++) {
			pp_src_dst_buf_sz[src_blk_idx][dst_blk_idx] = 0;

			if (dst_blk_idx == src_blk_idx){
				ppp_src_dst_pos[src_blk_idx][dst_blk_idx] = NULL;
				continue;
			}

			sorted_distinct_adj[dst_blk_idx].assign(distinct_adj[dst_blk_idx].begin(), distinct_adj[dst_blk_idx].end());
			std::sort(sorted_distinct_adj[dst_blk_idx].begin(), sorted_distinct_adj[dst_blk_idx].end());
//			printf("--------\n");
//			for (std::vector<int>::iterator iter = sorted_distinct_adj[dst_blk_idx].begin(); iter != sorted_distinct_adj[dst_blk_idx].end(); iter++) {
//				printf("%d ", *iter);
//			}
//			printf("--------\n");
			ppp_src_dst_pos[src_blk_idx][dst_blk_idx] = new int[sorted_distinct_adj[dst_blk_idx].size()];
			pp_src_dst_buf_sz[src_blk_idx][dst_blk_idx] = sorted_distinct_adj[dst_blk_idx].size();
			//printf("from %d to %d size %d\n", src_blk_idx, dst_blk_idx, sorted_distinct_adj[dst_blk_idx].size());
		}

		// 3.filling the ppp_src_dst_pos, ppp_src_dst_pos[src_blk_idx][dst_blk_idx][]
		// refill adj in buffer
		for (int v_idx = block.get_lbound(); v_idx < block.get_ubound(); v_idx++) {
			agraph::adj_list *p_adj_list = g.get_adj(v_idx);

			for (agraph::adj_list::iterator iter = p_adj_list->begin(); iter != p_adj_list->end(); iter++) {
				int adj = *iter;
				int adj_idx = iter - p_adj_list->begin();
				char dst_blk_idx = pp_blk_idx[v_idx][adj_idx];

				//out of block
				if (dst_blk_idx != src_blk_idx) {
//					int tmp = std::find(sorted_distinct_adj[dst_blk_idx].begin(), sorted_distinct_adj[dst_blk_idx].end(), adj)
//							- sorted_distinct_adj[dst_blk_idx].begin();
					//printf("adj %d in block %d-%d\n", adj, dst_blk_idx, tmp);
					//search adjacent node in where of buffer
					int pos_in_buf = Binary_search(sorted_distinct_adj[dst_blk_idx], adj);

					assert(pos_in_buf != -1);
					assert(pp_adj_pos[v_idx][adj_idx] == 0);

					pp_adj_pos[v_idx][adj_idx] = pos_in_buf;
					//int buff_ind = pp_src_dst_buf_sz[src_blk_idx][dst_blk_idx]++;
					ppp_src_dst_pos[src_blk_idx][dst_blk_idx][pos_in_buf] = adj;
				}
			}
		}
	}
}

}
#endif /* BLOCK_H_ */
