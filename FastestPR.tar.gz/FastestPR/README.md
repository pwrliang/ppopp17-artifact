# FastestPR
Try to implement PR on GPU
