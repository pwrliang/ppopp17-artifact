/*
 * graph.h
 *
 *  Created on: Jan 18, 2018
 *      Author: liang
 */

#ifndef GRAPH_H_
#define GRAPH_H_
#include <vector>
namespace agraph {
union gpu_adj {
//	long
};

typedef std::vector<int> adj_list;
class graph {
private:
	int num_vertex;
	int num_edge;
	bool loaded;
	adj_list **p_adj_table;
public:

	bool load_graph(const char *p_dataset_path);
	graph(int _num_vertex);

	int get_vertex_num();

	int get_edge_num();

	adj_list *get_adj(int v_idx);
	~graph();

};

graph::graph(int _num_vertex) :
		num_vertex(_num_vertex), num_edge(0), loaded(false) {
	p_adj_table = new adj_list*[_num_vertex];
	for (int v_idx = 0; v_idx < _num_vertex; v_idx++) {
		p_adj_table[v_idx] = new adj_list();
	}
}

int graph::graph::get_edge_num() {
	return num_edge;
}
int graph::get_vertex_num() {
	return num_vertex;
}

adj_list *graph::get_adj(int v_idx) {
	return p_adj_table[v_idx];
}

graph::~graph() {
	delete[] p_adj_table;
}

bool graph::load_graph(const char *p_dataset_path) {
	std::string line;
	std::ifstream infile(p_dataset_path);
	if (infile.fail()) {
		std::cerr << "file " << p_dataset_path << " does not exists"
				<< std::endl;
		return false;
	}

	int line_counter = 0;
	std::vector<std::string> temp_res;

	while (getline(infile, line)) {
		adj_list *p_adj_list = NULL;
		boost::split(temp_res, line, boost::is_any_of("\t "),
				boost::token_compress_on);

		bool first = true;
		int src_idx = -1;
		for (std::vector<std::string>::iterator iter = temp_res.begin();
				iter != temp_res.end(); iter++) {
			int v_idx = std::stoi(*iter);
			if (v_idx < 0 or v_idx >= num_vertex) {
				std::cerr << "error vertex id " << v_idx << std::endl;
				return false;
			}

			if (first) {
				src_idx = v_idx;
				p_adj_list = p_adj_table[src_idx];
				first = false;
			} else {
				p_adj_list->push_back(v_idx);
				num_edge++;
			}
		}
		assert(p_adj_list->size() > 0);

		//std::sort(p_adj_list->begin(), p_adj_list->end());

		temp_res.clear();

		if (line_counter > 0 && line_counter % 10000 == 0)
			std::cout << "parsed " << line_counter << " lines" << std::endl;
		line_counter++;
		if (line_counter > num_vertex) {
			std::cerr << "error vertex number: " << src_idx << std::endl;
			return false;
		}
	}
	infile.close();
	if (line_counter != num_vertex) {
		std::cerr << "error vertex number: " << line_counter << std::endl;
		return false;
	}
	std::cout << "----------graph loaded----------" << std::endl;
	std::cout << "vertex: " << num_vertex << std::endl;
	std::cout << "edge: " << num_edge << std::endl;
	std::cout << "----------graph loaded----------" << std::endl;
	loaded = true;
	return true;
}
}

#endif /* GRAPH_H_ */
