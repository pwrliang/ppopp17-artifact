/*
 * partitioner.h
 *
 *  Created on: Jan 22, 2018
 *      Author: liang
 */

#ifndef PARTITIONER_H_
#define PARTITIONER_H_
#include "graph.h"
#include <kernel/partitioned_pagerank.cuh>
#include <vector>
namespace agraph {

int splitVertex(agraph::graph &g, std::vector<int> &partialAdj, int vertexIdx,
		int lastUsedPos, int len) {
	adj_list * adjList = g.get_adj(vertexIdx);

	assert(!(lastUsedPos + len > adjList->size()));
	//bug is here....
//	for (adj_list::iterator iter = adjList->begin() + lastUsedPos;
//			iter != adjList->begin() + lastUsedPos + len; iter++)
//		partialAdj.push_back(*iter);
	partialAdj.insert(partialAdj.end(), adjList->begin() + lastUsedPos,
			adjList->begin() + lastUsedPos + len);

	return lastUsedPos + len;
}

void balanced_partitioner(agraph::graph &g, int blocksPerGrid,
		int threadsPerBlock, std::vector<agraph::adj_list> *threadTasks) {
	int totalThreadsNum = blocksPerGrid * threadsPerBlock;
	int totalDegree = 0;
	int avgDgrPerThread = 0;

	for (int vertexIdx = 0; vertexIdx < g.get_vertex_num(); vertexIdx++) {
		totalDegree += g.get_adj(vertexIdx)->size();
	}

	avgDgrPerThread = totalDegree / totalThreadsNum;

	printf("total dgr:%d avg dgr:%d\n", totalDegree, avgDgrPerThread);
	assert(avgDgrPerThread > 0);

	int vertexIdx = 0;

	int *pAdjSize = new int[g.get_vertex_num()];

	for (int vertexIdx = 0; vertexIdx < g.get_vertex_num(); vertexIdx++) {
		pAdjSize[vertexIdx] = g.get_adj(vertexIdx)->size();
	}

	int lastUsedPos = 0;

	for (int threadIdx = 0; threadIdx < totalThreadsNum; threadIdx++) {
		// this is border thread
		if ((threadIdx + 1) % 32 == 0 && threadIdx != totalThreadsNum - 1) {
			int addedDgrSize = 0;
			// still remain partial adjacent list
			if (lastUsedPos > 0) {
				adj_list partialAdjList;

				partialAdjList.push_back(vertexIdx);
				partialAdjList.push_back(g.get_adj(vertexIdx)->size());
				partialAdjList.push_back(0); // not first part

				adj_list *pAdjList = g.get_adj(vertexIdx);

				for (agraph::adj_list::iterator iter = pAdjList->begin()
						+ lastUsedPos; iter != pAdjList->end(); iter++) {
					partialAdjList.push_back(*iter);
					pAdjSize[vertexIdx]--;
				}

				partialAdjList.push_back(-1); // end tag
				threadTasks[threadIdx].push_back(partialAdjList);
				addedDgrSize += pAdjList->size() - lastUsedPos;
				vertexIdx++;
				lastUsedPos = 0;
			}

			int restLen = avgDgrPerThread - addedDgrSize;

			//this thread remain space
			while (restLen > 0) {
				assert(vertexIdx < g.get_vertex_num());
				adj_list *pAdjList = g.get_adj(vertexIdx);
				adj_list adjList;

				adjList.push_back(vertexIdx);
				adjList.push_back(pAdjList->size());
				adjList.push_back(1); // first part, because don't split

				for (agraph::adj_list::iterator iter = pAdjList->begin();
						iter != pAdjList->end(); iter++) {
					adjList.push_back(*iter);
					pAdjSize[vertexIdx]--;
				}

				adjList.push_back(-1); // end tag
				threadTasks[threadIdx].push_back(adjList);
				addedDgrSize += pAdjList->size();
				vertexIdx++;
				lastUsedPos = 0;
				restLen = avgDgrPerThread - addedDgrSize;
			}
		} else {
			int addedDgrSize = 0;
			int restLen = avgDgrPerThread - addedDgrSize;

			while (restLen > 0) {
				if (vertexIdx >= g.get_vertex_num())
					goto end;
				assert(vertexIdx < g.get_vertex_num());
				adj_list partialAdjList;

				partialAdjList.push_back(vertexIdx);
				partialAdjList.push_back(g.get_adj(vertexIdx)->size());
				partialAdjList.push_back(lastUsedPos == 0 ? 1 : 0); // if last part is remain, tag split

				// this vertex can put it all on threadIdx
				if (pAdjSize[vertexIdx] <= restLen) {
					adj_list *pAdjList = g.get_adj(vertexIdx);

					for (agraph::adj_list::iterator iter = pAdjList->begin()
							+ lastUsedPos; iter != pAdjList->end(); iter++) {
						partialAdjList.push_back(*iter);
						pAdjSize[vertexIdx]--;
					}

					partialAdjList.push_back(-1); // end tag
					threadTasks[threadIdx].push_back(partialAdjList);
					addedDgrSize += pAdjList->size() - lastUsedPos;
					vertexIdx++;
					lastUsedPos = 0;
				} else {
					pAdjSize[vertexIdx] -= restLen; // consume part of adjacent list
					addedDgrSize += restLen;
					lastUsedPos = splitVertex(g, partialAdjList, vertexIdx,
							lastUsedPos, restLen);
					partialAdjList.push_back(-1); // end tag
					threadTasks[threadIdx].push_back(partialAdjList);
				}
				restLen = avgDgrPerThread - addedDgrSize;
			}
		}

		// last thread
		if (threadIdx == totalThreadsNum - 1
				&& vertexIdx < g.get_vertex_num()) {

			// if here are rest of sliced adjacent list
			if (lastUsedPos > 0) {
				assert(vertexIdx < g.get_vertex_num());
				adj_list *pAdjList = g.get_adj(vertexIdx);
				adj_list adjList;

				assert(lastUsedPos < g.get_adj(vertexIdx)->size());
				adjList.push_back(vertexIdx);
				adjList.push_back(g.get_adj(vertexIdx)->size());
				adjList.push_back(0); // remain sliced part, tag with 0

				while (lastUsedPos < g.get_adj(vertexIdx)->size()) {
					adjList.push_back(pAdjList->at(lastUsedPos++));
					pAdjSize[vertexIdx]--;
				}

				adjList.push_back(-1); // end tag
				threadTasks[threadIdx].push_back(adjList);
				vertexIdx++;
				lastUsedPos = 0;
			}

			while (vertexIdx < g.get_vertex_num()) {
				adj_list adjList;

				adjList.push_back(vertexIdx);
				adjList.push_back(g.get_adj(vertexIdx)->size());
				adjList.push_back(1); // no split, tag with 1
				adjList.insert(adjList.end(), g.get_adj(vertexIdx)->begin(),
						g.get_adj(vertexIdx)->end());
				adjList.push_back(-1); // end tag
				threadTasks[threadIdx].push_back(adjList);
				pAdjSize[vertexIdx] = 0;
				vertexIdx++;
			}
		}
	}

	for (int threadIdx = 0; threadIdx < totalThreadsNum; threadIdx++)
		assert(threadTasks[threadIdx].size() > 0);

	for (int vertexIdx = 0; vertexIdx < g.get_vertex_num(); vertexIdx++)
		assert(pAdjSize[vertexIdx] == 0);
	return;
	end: std::cout << "warn: too many threads" << std::endl;
}

void balanced_partitioner_simple(agraph::graph &g, int blocksPerGrid,
		int threadsPerBlock, std::vector<agraph::adj_list> *threadTasks) {
	int totalThreadsNum = blocksPerGrid * threadsPerBlock;
	int totalDegree = 0;
	int avgDgrPerThread = 0;
	int avgVertexThread = 0;

	for (int vertexIdx = 0; vertexIdx < g.get_vertex_num(); vertexIdx++) {
		totalDegree += g.get_adj(vertexIdx)->size();
	}

	avgDgrPerThread = totalDegree / totalThreadsNum;
	avgVertexThread = g.get_vertex_num() / totalThreadsNum;

	printf("total dgr:%d thread num:%d avg dgr:%d avg vertex:%d\n", totalDegree,
			totalThreadsNum, avgDgrPerThread, avgVertexThread);
	assert(avgDgrPerThread > 0);
	assert(avgVertexThread > 0);

	int vertexIdx = 0;

	for (int threadIdx = 0; threadIdx < totalThreadsNum; threadIdx++) {
		int addedDgrSize = 0;
		int restLen = avgDgrPerThread;
		// this is border thread

		if (threadIdx == totalThreadsNum - 1) {
			while (vertexIdx < g.get_vertex_num()) {
				adj_list *pAdjList = g.get_adj(vertexIdx);
				adj_list adjList;

				adjList.push_back(vertexIdx);
				adjList.push_back(g.get_adj(vertexIdx)->size());
				adjList.insert(adjList.end(), pAdjList->begin(),
						pAdjList->end());
				adjList.push_back(-1); // end tag
				threadTasks[threadIdx].push_back(adjList);
				vertexIdx++;
			}
		} else {
			while (vertexIdx < g.get_vertex_num()
					&& threadTasks[threadIdx].size() < avgVertexThread) {
				adj_list *pAdjList = g.get_adj(vertexIdx);
				adj_list adjList;

				// if not first task and more than rest length, then skip
				if (pAdjList->size() > restLen && restLen != avgDgrPerThread)
					break;

				adjList.push_back(vertexIdx);
				adjList.push_back(g.get_adj(vertexIdx)->size());
				adjList.insert(adjList.end(), pAdjList->begin(),
						pAdjList->end());
				adjList.push_back(-1); // end tag

				threadTasks[threadIdx].push_back(adjList);
				addedDgrSize += pAdjList->size();
				vertexIdx++;
				restLen = avgDgrPerThread - addedDgrSize;
			}
		}
	}
	printf("vertex id:%d\n", vertexIdx);
}

void convert(int threadsNum, std::vector<agraph::adj_list> *threadTasks,
		int *hd_tasksNumPerThread, int ***hd_hd_d_Tasks) {
	for (int threadIdx = 0; threadIdx < threadsNum; threadIdx++) {
		int tasksNum = threadTasks[threadIdx].size();
		hd_tasksNumPerThread[threadIdx] = tasksNum;

		if(tasksNum == 0)
			continue;
		CHECK(
				cudaMallocManaged(&hd_hd_d_Tasks[threadIdx],
						sizeof(int*) * tasksNum));
		for (int taskIdx = 0; taskIdx < tasksNum; taskIdx++) {
			CHECK(
					cudaMalloc(&hd_hd_d_Tasks[threadIdx][taskIdx],
							sizeof(int)
									* threadTasks[threadIdx][taskIdx].size()));
			CHECK(
					cudaMemcpy(hd_hd_d_Tasks[threadIdx][taskIdx],
							threadTasks[threadIdx][taskIdx].data(),
							sizeof(int)
									* threadTasks[threadIdx][taskIdx].size(),
							cudaMemcpyHostToDevice));

		}
	}
}

//#define DEBUG
void partitioner_test() {
#ifdef DEBUG
	int blocksPerGrid = 4;
	int threadsPerBlock = 2;

	agraph::graph g(17);
	g.load_graph("/home/liang/test_dataset");
#else
	int blocksPerGrid = 20;
	int threadsPerBlock = 128;

//	agraph::graph g(875713);
//	g.load_graph("/home/liang/Datasets/google_adj_replaced.txt");

//	agraph::graph g(4847571);
//	g.load_graph("/home/liang/Datasets/livej_edge_adj_replaced.txt");

	agraph::graph g(2987535);
	g.load_graph("/home/liang/Datasets/wikitalk_adj.txt");
#endif
	int totalThreadsNum = blocksPerGrid * threadsPerBlock;

	std::vector<agraph::adj_list> *threadTasks = new std::vector<
			agraph::adj_list>[totalThreadsNum];
	printf("start partitioning\n");
	balanced_partitioner(g, blocksPerGrid, threadsPerBlock, threadTasks);
//	balanced_partitioner_simple(g, blocksPerGrid, threadsPerBlock, threadTasks);
	printf("partitioned\n");

	int ***hd_hd_d_Tasks;
	int *d_p_tasksNumPerThread;

	cudaSetDevice(1);

	CHECK(cudaMallocManaged(&hd_hd_d_Tasks, sizeof(int**) * totalThreadsNum));
	CHECK(
			cudaMallocManaged(&d_p_tasksNumPerThread,
					sizeof(int) * totalThreadsNum));
	convert(totalThreadsNum, threadTasks, d_p_tasksNumPerThread, hd_hd_d_Tasks);
	float *h_value = new float[g.get_vertex_num()];
	float *h_delta = new float[g.get_vertex_num()];
	float *d_value, *d_delta, *d_deltaBuffer;

	for (int vertexIdx = 0; vertexIdx < g.get_vertex_num(); vertexIdx++) {
		h_value[vertexIdx] = 0.0f;
		h_delta[vertexIdx] = 0.2f / g.get_vertex_num();
	}

	CHECK(cudaMalloc(&d_value, sizeof(float) * g.get_vertex_num()));
	CHECK(
			cudaMemcpy(d_value, h_value, sizeof(float) * g.get_vertex_num(),
					cudaMemcpyHostToDevice));
	CHECK(cudaMalloc(&d_delta, sizeof(float) * g.get_vertex_num()));
	CHECK(
			cudaMemcpy(d_delta, h_delta, sizeof(float) * g.get_vertex_num(),
					cudaMemcpyHostToDevice));
	CHECK(cudaMalloc(&d_deltaBuffer, sizeof(float) * g.get_vertex_num()));

	printf("copyed\n");

	float *d_p_buffer;
	int cacheSize = threadsPerBlock / 32;

	assert(cacheSize > 0);
	CHECK(cudaMalloc(&d_p_buffer, sizeof(float) * blocksPerGrid));
	CHECK(cudaMemset(d_p_buffer, 0, sizeof(float) * blocksPerGrid));

	float running_time = 0.0f;
	cudaEvent_t start, stop;

	cudaEventCreate(&start);
	cudaEventCreate(&stop);
	cudaEventRecord(start);
	async_pagerank_partitioned<<<blocksPerGrid, threadsPerBlock, cacheSize>>>(
			g.get_vertex_num(), d_p_tasksNumPerThread, d_value, d_delta,
			d_deltaBuffer, d_p_buffer, hd_hd_d_Tasks);
	cudaDeviceSynchronize();
	cudaEventRecord(stop);
	cudaEventSynchronize(stop);
	cudaEventElapsedTime(&running_time, start, stop);
	std::cout << "elapsed " << running_time << std::endl;
	return;
	CHECK(
			cudaMemcpy(h_value, d_value, sizeof(float) * g.get_vertex_num(),
					cudaMemcpyDeviceToHost));
	for (int vertexIdx = 0; vertexIdx < g.get_vertex_num(); vertexIdx++) {
		printf("%d %f\n", vertexIdx, h_value[vertexIdx]);
	}
	return;

	for (int threadIdx = 0; threadIdx < totalThreadsNum; threadIdx++) {
		std::vector<agraph::adj_list> adjList = threadTasks[threadIdx];
		std::cout << "thread " << threadIdx << std::endl;
		std::cout << "blocks " << adjList.size() << std::endl;
		int totalDgr = 0;
		for (std::vector<agraph::adj_list>::iterator iter = adjList.begin();
				iter != adjList.end(); iter++) {
			agraph::adj_list adj = *iter;
			totalDgr += adj.size();
//			for (agraph::adj_list::iterator adjI = adj.begin();
//					adjI != adj.end(); adjI++) {
//				std::cout << *adjI << " ";
//			}
//			std::cout << std::endl;
		}
		printf("threadIdx:%d total dgr:%d\n", threadIdx, totalDgr);
	}
}

}

#endif /* PARTITIONER_H_ */
